import express, { Request, Response } from 'express';
import { Query } from 'express-serve-static-core';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';



interface Submission {
  name: string;
  email: string;
  phone: string;
  github_link: string;
  stopwatch_time: string;
}

const app: express.Application = express();
app.use(bodyParser.json());

const dbFile: string = path.join(__dirname, 'db.json');

// Ping endpoint
app.get('/ping', (req: Request, res: Response) => {
  res.json({ success: true });
});

// Submit endpoint
app.post('/submit', (req: Request, res: Response) => {
  const { name, email, phone, github_link, stopwatch_time }: Submission = req.body;
  const submission: Submission = { name, email, phone, github_link, stopwatch_time };
  fs.readFile(dbFile, (err: NodeJS.ErrnoException | null, data: Buffer) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to read database' });
    } else {
      const db: Submission[] = JSON.parse(data.toString()); // Convert Buffer to string
      db.push(submission);
      fs.writeFile(dbFile, JSON.stringify(db), (err: NodeJS.ErrnoException | null) => {
        if (err) {
          console.error(err);
          res.status(500).json({ error: 'Failed to write to database' });
        } else {
          res.json({ success: true });
        }
      });
    }
  });
});

// Read endpoint
app.get('/read', (req: Request, res: Response) => {
  let index: number | undefined;
  if (typeof req.query.index === 'string') {
    index = parseInt(req.query.index, 10);
  }
  fs.readFile(dbFile, (err: NodeJS.ErrnoException | null, data: Buffer) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to read database' });
    } else {
      const db: Submission[] = JSON.parse(data.toString()); // Convert Buffer to string
      if (index !== undefined && index >= 0 && index < db.length) {
        res.json(db[index]);
      } else {
        res.status(404).json({ error: 'Submission not found' });
      }
    }
  });
});

// Search endpoint
app.get('/search', (req: Request, res: Response) => {
    let query: string;
    if (typeof req.query.query === 'string') {
      query = req.query.query;
    } else {
      res.status(400).json({ error: 'Invalid query parameter' });
      return;
    }
  
    fs.readFile(dbFile, (err: NodeJS.ErrnoException | null, data: Buffer) => {
      if (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to read database' });
      } else {
        const db: Submission[] = JSON.parse(data.toString()); // Convert Buffer to string
        const results: Submission[] = db.filter((submission: Submission) => {
          return submission.email.includes(query);
        });
        res.json(results);
      }
    });
  });

app.listen(3000, '0.0.0.0', () => {
    console.log('Server started on port 3000');
  });